import logo1 from "./logo1.svg";
import github from "./github.png";
import menu from "./menu.svg";
import close from "./close.svg";
import linkedin from "./linkedin.webp";
import resume from "./resume.png";

import python3 from "./tech/python3.png"
import html from "./tech/html.png";
import css from "./tech/css.png";
import javascript from "./tech/javascript.png";
import mongodb from "./tech/mongodb.png";
import expressjs from "./tech/expressjs.webp";
import reactjs from "./tech/reactjs.png";
import nodejs from "./tech/nodejs.png";
import bootstrap from "./tech/bootstrap.png";
import tailwind from "./tech/tailwind.png";
import threejs from "./tech/threejs.svg";
import figma from "./tech/figma.png";
import powerbi from "./tech/powerbi.png";
import git from "./tech/git.png";


import habib from "./company/habib.jpg";
import headstarter from "./company/headstarter.jpg";
import idara from "./company/idara.jpg";
import rtc from "./company/rtc.jpg";

import imagerec from "./imagerec.png";
import coffee from "./coffeestore.png";
import tictactoe from "./tictactoe.png";

export {
  logo1,
  github,
  linkedin,
  resume,
  menu,
  close,
  css,
  bootstrap,
  expressjs,
  figma,
  git,
  html,
  javascript,
  mongodb,
  nodejs,
  powerbi,
  python3,
  reactjs,
  tailwind,
  threejs,
  habib,
  rtc,
  idara,
  headstarter,
  imagerec,
  coffee,
  tictactoe,
};
