import {
  github,
  resume,
  linkedin,
  css,
  bootstrap,
  expressjs,
  figma,
  git,
  html,
  javascript,
  mongodb,
  nodejs,
  powerbi,
  python3,
  reactjs,
  tailwind,
  threejs,
  habib,
  headstarter,
  idara,
  rtc,
  imagerec,
  coffee,
  tictactoe,
} from "../assets";

export const navLinks = [
  {
    id: "about",
    title: "About",
  },
  {
    id: "work",
    title: "Work",
  },
  {
    id: "contact",
    title: "Contact",
  },
];


const services = [
  {
    title: "GitHub",
    icon: github,
    link: "https://github.com/ctrlaltdef"
  },
  {
    title: "LinkedIn",
    icon: linkedin,
    link: "https://www.linkedin.com/in/yusra-faisal/"
  },
  {
    title: "Resume",
    icon: resume,
    link: "https://drive.google.com/file/d/1ip8PdXOj1zbovT4zytrxxBzOzIq421Za/view?usp=sharing"
  },
];


const technologies = [
  {
    name: "Python3",
    icon: python3,
  },
  {
    name: "HTML 5",
    icon: html,
  },
  {
    name: "CSS 3",
    icon: css,
  },
  {
    name: "JavaScript",
    icon: javascript,
  },
  {
    name: "Bootstrap 5",
    icon: bootstrap,
  },
  {
    name: "Tailwind Css",
    icon: tailwind,
  },
  {
    name: "Three JS",
    icon: threejs,
  },
  {
    name: "MongoDB",
    icon: mongodb,
  },
  {
    name: "Express Js",
    icon: expressjs,
  },
  {
    name: "React JS",
    icon: reactjs,
  },
  {
    name: "Node JS",
    icon: nodejs,
  },
  {
    name: "git",
    icon: git,
  },
  {
    name: "figma",
    icon: figma,
  },
];

const experiences = [
  {
    title: "Software Engineering Fellow",
    company_name: "Headstarter AI",
    icon: headstarter,
    iconBg: "#00E4B3",
    date: "July 2024 - September 2024",
    points: [
      "Building 5+ Al apps and APIs using NextJS, OpenAl, Pinecone, StripeAPI with 98% accuracy as seen by 1000 users.",
      "Developing projects from design to deployment leading 4+ engineering fellows using MVC design patterns.",
      "Getting coached by Amazon, Bloomberg and Capital One engineers on Agile, CI/CD, Git and microservice patterns.",
      "Participating in weekly mock coding interviews and hackathons.",
    ],
  },
  {
    title: "Member",
    company_name: "Rewriting the Code",
    icon: rtc,
    iconBg: "#FE5900",
    date: "July 2024 - Present",
    points: [
      "Engaged in a global network supporting women in tech, offering valuable mentorship and resources.",
      "Participating in workshops and events to enhance skills and knowledge.",
      "Collaborating with a diverse group of professionals and industry leaders to increase diversity and inclusion in tech.",
      "Involved in programs that provide career development and personal growth.",
    ],
  },
  {
    title: "Fellow, Career Academy",
    company_name: "Habib University",
    icon: habib,
    iconBg: "#5D2469",
    date: "May 2024 - Present",
    points: [
      "Completed Power BI training, gaining skills in data collection, cleaning, analysis, and visualization.",
      "Connected with professionals with successful careers to learn networking strategies and gain insights.",
      "Attended workshops on personal branding, project management, marketing, entrepreneurship, leadership, and emotional intelligence.",
      "Participated in seminars on AI, quantum computing, and machine learning, gaining valuable knowledge about the future of various industries.",
    ],
  },
  {
    title: "Summer Intern",
    company_name: "Idara Al-Khair Welfare Society",
    icon: idara,
    iconBg: "#D8BC73",
    date: "June 2019 - July 2019",
    points: [
      "Completed 30 hours of volunteer work, teaching lessons and organizing activities for 3-10 year old students.",
      "Delivered motivational lectures, fostering a positive and engaging learning environment.",
      "Participated in Splash 2.0, collaborating with volunteers to revamp school walls and create an inviting atmosphere for underprivileged students.",
    ],
  },
];


const projects = [
  {
    name: "ColorMatch",
    description:
      "Developed a KD-tree based image recommendation system that suggests similar images based on color similarity, featuring a user-friendly TKINTER GUI.",
    tags: [
      {
        name: "python3",
        color: "blue-text-gradient",
      },
      {
        name: "tkinter",
        color: "green-text-gradient",
      },
    ],
    image: imagerec,
    source_code_link: "https://github.com/ctrlaltdef/similar-color-image-recommendation-system-using-kd-tree",
  },
  {
    name: "JavaBrew Cafe",
    description:
      "Developed an online coffee store as my first front-end project, utilizing HTML, CSS, and JavaScript to create a responsive, interactive, and visually appealing website.",
    tags: [
      {
        name: "Html5",
        color: "blue-text-gradient",
      },
      {
        name: "CSS3",
        color: "green-text-gradient",
      },
      {
        name: "JavaScript",
        color: "pink-text-gradient",
      },
    ],
    image: coffee,
    source_code_link: "https://github.com/ctrlaltdef/Coffee-ecommerce-store-Front-End-Project-",
  },
  {
    name: "Tic Tac Toe",
    description:
      "Created a classic Tic Tac Toe game with an intuitive interface and responsive web design, allowing two players to enjoy a seamless and engaging experience.",
    tags: [
      {
        name: "Html5",
        color: "blue-text-gradient",
      },
      {
        name: "CSS3",
        color: "green-text-gradient",
      },
      {
        name: "JavaScript",
        color: "pink-text-gradient",
      },
    ],
    image: tictactoe,
    source_code_link: "https://github.com/ctrlaltdef/Tic-Tac-Toe-Game-Front-End-Practice-Project-",
  },
];

export { services, technologies, experiences, projects };
